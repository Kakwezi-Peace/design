package com.Hotel.amanagement.and.booking.application.Hotel.amanagement.and.booking.application;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelAmanagementAndBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
