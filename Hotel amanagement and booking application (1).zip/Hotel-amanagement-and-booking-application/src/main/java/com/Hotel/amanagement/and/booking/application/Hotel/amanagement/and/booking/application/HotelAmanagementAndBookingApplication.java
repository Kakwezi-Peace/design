package com.Hotel.amanagement.and.booking.application.Hotel.amanagement.and.booking.application;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HotelAmanagementAndBookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(HotelAmanagementAndBookingApplication.class, args);
	}

}
